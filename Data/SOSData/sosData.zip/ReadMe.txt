Data of SOS system reporter plasmids 

The data is of the calculated 
promoter activity (GFP/min/OD)

It appears in two formats, matlab and txt:

Data_sos.mat  %%% contains the variables: 
			sosData1       (4x8x50)
				     4 experiments, 8 operons, 50 time points  
			time           1x50 
			
			
			where experiments 1 & 2: UV=5 Jm-2
				experiments 3 & 4: UV=20 Jm-2

				reporter plasmids order:
				1-uvrD  2-lexA 3-umuD  4-recA  
				5-uvrA  6-uvrY  7-ruvA  8-polB


Ex1.txt 	%%%%%    File for each experiment
Ex2.txt	
Ex3.txt
Ex4.txt
	
	





